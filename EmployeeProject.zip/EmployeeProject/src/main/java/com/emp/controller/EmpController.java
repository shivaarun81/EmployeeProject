package com.emp.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emp.model.EmployeeModel;
import com.emp.service.EmployeeService;
/**
 * 
 * @author Arun Pandian K
 *
 */
@RestController
@RequestMapping("/employee")
public class EmpController {
	
	@Autowired
	private EmployeeService empService;
	
	private static final Logger logger = LogManager.getLogger(EmpController.class);
	
	/*
	 * Save or update request handler
	 * Based on the Id, it will decide
	 * For example if id is 0 it will save or else update.
	 * Send the Response back with employee id.
	 */
	@PostMapping("/add")
	public ResponseEntity<?> employeeAdd(@RequestBody EmployeeModel empModel )
	{
		String resMessage=null;
		try
		{
		int empId = empService.employeeSave(empModel);
		if(empModel.getId() == 0)
			resMessage = "Employee Id "+ empId +" Created";
		else
			resMessage = "Employee Id "+ empId +" Updated";
		logger.info(resMessage);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		return new ResponseEntity<>(resMessage,HttpStatus.OK);
	}
	/*
	 * 
	 * Get all employee information
	 * Response all the employee data in JSON Format
	 */
	@GetMapping("/getall")
	public ResponseEntity<?> employeeGetAll()
	{
		List<EmployeeModel> empModel = empService.getAll();
		logger.info("Requested Get All employee details");
		return new ResponseEntity<>(empModel,HttpStatus.OK);
	}
	/*
	 * Get the employee by id
	 * Check whether particular employee id exist or not.
	 * Based on condition response will send
	 */
	@GetMapping("byid/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") int id)
	{
		EmployeeModel empModel = empService.getByID(id);
		String resMsg = "Not able to find the request ID = "+id;
		if(empModel.getId() == 0)
			return new ResponseEntity<>(resMsg,HttpStatus.NOT_FOUND);
		else
		  return new ResponseEntity<>(empModel,HttpStatus.OK);
	}
	/*
	 * Delete the employee based on id.
	 *  Check whether particular employee id exist or not.
	 *  Based on condition response will send
	 */
	@DeleteMapping("byid/{id}")
	public ResponseEntity<?> deleteById(@PathVariable("id")int id)
	{
		EmployeeModel empModel = empService.getByID(id);
		if(empModel.getId() == 0)
		{
			logger.info("The Request ID not exist!");
			return new ResponseEntity<>("The Request ID not exist!",HttpStatus.NOT_FOUND);			
		}
		boolean res =  empService.deleteById(id);
		String resMsg = "The requested data deleted";
		if(!res)
			resMsg = "The requested not able data deleted";
		
		 return new ResponseEntity<>(resMsg,HttpStatus.OK);
	}
	
}
