package com.emp.service;

import java.util.List;

import com.emp.model.EmployeeModel;
/**
 * 
 * @author Arun Pandian K
 *
 */
public interface EmployeeService {

	int employeeSave(EmployeeModel empModel); 
	List<EmployeeModel> getAll();
	EmployeeModel getByID(int id);
	boolean deleteById(int id);
}
