package com.emp.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.dto.EmployeeDto;
import com.emp.model.EmployeeModel;
import com.emp.repository.EmployeeRepository;
import com.emp.service.EmployeeService;
/**
 * 
 * @author Arun Pandian K
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository empRepository;

	private static final ModelMapper modelMapper = new ModelMapper();

	private static final Logger logger = LogManager.getLogger(EmployeeServiceImpl.class);

	/*
	 * Save or Update function
	 * Based on the id, it will decide save/update
	 * For example if id is 0 it will save or else update.
	 */
	public int employeeSave(EmployeeModel empModel) {
		EmployeeDto empDto = modelMapper.map(empModel, EmployeeDto.class);
		try {
			empDto.setActive(true);
			empRepository.save(empDto);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return empDto.getId();

	}

	/*
	* Get all the employee details where the status column is true
	* its handled in Entity class level
	 */
	public List<EmployeeModel> getAll() {

		List<EmployeeModel> listEmp = new ArrayList<>();
		try {
			List<EmployeeDto> allEmp = empRepository.findAll();
			for (EmployeeDto empdto : allEmp) {
				EmployeeModel singleEmp = modelMapper.map(empdto, EmployeeModel.class);
				listEmp.add(singleEmp);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return listEmp;
	}

	/*
	 * Get the Employee details based on id
	 */
	@Override
	public EmployeeModel getByID(int id) {
		EmployeeDto singleEmp = new EmployeeDto();
		try {
			Optional<EmployeeDto> empdto = empRepository.findById(id);

			if (empdto.isPresent()) {
				singleEmp = empdto.get();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return modelMapper.map(singleEmp, EmployeeModel.class);
	}

	/*
	 * To achieve soft delete
	 * set the status as false for requested id
	 */
	@Override
	public boolean deleteById(int id) {
		try {
			empRepository.setStatus(false, id);
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

}
