package com.emp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author Arun Pandian K
 *
 */
@SpringBootApplication
public class SpringConfiguration {
	private static final Logger LOGGER = LogManager.getLogger(SpringConfiguration.class);
	public static void main(String[] args)
	{
		SpringApplication.run(SpringConfiguration.class, args);
		LOGGER.info("Application started...");
	}
}
