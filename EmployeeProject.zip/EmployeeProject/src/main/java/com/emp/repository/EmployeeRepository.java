package com.emp.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.emp.dto.EmployeeDto;
/**
 * 
 * @author Arun Pandian K
 *
 */
@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeDto,Integer> {

	
	/*
	 * For soft delete , custom query
	 */
	@Transactional
	@Modifying
	@Query(value = "UPDATE EmployeeDto SET is_active=:status WHERE id=:id")
	void setStatus(@Param("status") boolean status,@Param("id") int id);
	
}
