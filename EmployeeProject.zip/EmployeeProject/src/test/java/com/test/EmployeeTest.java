package com.test;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.emp.SpringConfiguration;
import com.emp.model.EmployeeModel;
import com.emp.service.EmployeeService;
/**
 * 
 * @author Arun Pandian K
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringConfiguration.class)
public class EmployeeTest {
	
	@Autowired
	private EmployeeService empService;
	
	private static final Logger logger = LogManager.getLogger(EmployeeTest.class);
	
	@Test
	public void employeeAdd()
	{
		EmployeeModel empModel = new EmployeeModel();
		empModel.setFirstName("arun");
		empModel.setLastName("k");
		empModel.setGender("male");
		empModel.setEmailId("arun@gmail.com");
		empModel.setAddress("bangalore");
		int id = empService.employeeSave(empModel);
		logger.info("Employee Add - Junit Test");
		assertTrue(id != 0);
	}
	
	@Test
	public void getAll()
	{
		empService.getAll();
		logger.info("Employee Retrieve all data - Junit Test");
	}
	
	@Test
	public void getById()
	{
		int id = 8;
		EmployeeModel empModel = empService.getByID(id);
		assertSame(empModel.getId(),id);
		logger.info("Employee Get By Id - Junit Test");
	}
	
	@Test
	public void delete()
	{
		int id = 7;
		boolean res = empService.deleteById(id);
		assertTrue(res);
		logger.info("Employee Soft Delete- Junit Test");
	}
}
